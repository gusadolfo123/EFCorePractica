# EFCorePractica
Practica EFCore
