﻿namespace EFdNorthWind.Helpers
{
    public class AppConfiguration
    {
        public string DatabaseProvider { get; set; }

        public string ConnectionString { get; set; }  
    }
}
